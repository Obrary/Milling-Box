Product: Milling Box, November 2014

Designer: FabLab Sevilla

Support:  http://forums.obrary.com/category/designs/milling-box

Distributed by:  Obrary, Inc.  http://obrary.com.

Obrary - democratized product design